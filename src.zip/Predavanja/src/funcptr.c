#include <stdio.h>
#include <math.h>

typedef double trigFunc(double);

int vsota(int x, int y) {
  return x+y;
}

int produkt(int x, int y) {
  return x*y;
}

int funkcija(int (*f)(int, int), int x, int y) {
  return (*f)(x,y);
}

double trig(trigFunc *f, double x) {
  return (*f)(x);
}

int main(int argv, char **args) {
  
  int a=5;
  int b=7;

  int c = funkcija(vsota, a, b);
  printf("%d\n", c);

  c = funkcija(produkt, a, b);
  printf("%d\n", c);

  double x=0;
  printf("%.2f\n", trig(sin, x));  
  printf("%.2f\n", trig(cos, x));
  
  return 0;
}
