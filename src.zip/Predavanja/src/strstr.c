#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **args) {

  char *niz = "To je moj niz";
  while(niz != NULL) {
    printf("%p - '%s'\n", niz, niz);
    niz++;
    niz = strstr(niz, " ");
  }

  return 0;
}
