#include <stdio.h>


typedef struct kompleksno {
  double x;
  double y;
} cplx;

cplx sestej(cplx w, cplx z) {
  w.x += z.x;
  w.y += z.y;
  return w;
  
  //return (cplx){w.x+z.x, w.y+z.y};
}

int main(int argc, char **args) {

  cplx a = {3,4};
  
  cplx b = {.y=7, .x=5};

  cplx vsota = sestej(a,b);
  printf("%.2f + %.2f i \n", vsota.x, vsota.y);
}
