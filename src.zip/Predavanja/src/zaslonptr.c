#include <stdio.h>
#include <stdlib.h>

#define W 79
#define H 25

int main(int argc, char **args) {
  int i,j;

  // rezerviram pomnilnik 
  char **zaslon =(char**) malloc(H*sizeof(char *));
  for(i=0; i<H; i++)
    zaslon[i] = (char*) malloc(W*sizeof(char));


  char znaki[] = {'#','%','*',' '};
  for(i=0; i<H; i++)
    for(j=0; j<W; j++)
      zaslon[i][j] = znaki[(i+j)%4];

  for(i=0; i<H; i++) {
    for(j=0; j<W; j++)
      printf("%c", zaslon[i][j]);
    printf("\n");
  }

  // sprostim pomnilnik
  for(i=0; i<H; i++)
    free(zaslon[i]);
  free(zaslon);
}
