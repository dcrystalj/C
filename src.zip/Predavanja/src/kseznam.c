#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct element {
  // podatkovni del
  char *ime;

  // povezovalni del
  struct element *nasl;
} elt;

// naredi nov element (rezervira pomnilnik)
// in vrne kazalec nanj
elt * newElement(char *ime) {
  elt *nov = malloc(sizeof(elt));
  nov->nasl = NULL;
  nov->ime  = malloc((strlen(ime)+1)*sizeof(char));
  strcpy(nov->ime, ime);
  return nov;
}

void sprostiElement(elt *e) {
  free(e->ime);
  free(e);
}

void izpisiElement(elt *e) {
  printf("Ime : %s\n", e->ime);
}

void izpisiSeznam(elt *z) {
  while (z != NULL) {
    izpisiElement(z);
    z = z->nasl;
  }
}

// dodajanje na zacetek seznama
elt * push(elt *z, elt *e) {
  e->nasl=z;
  return e;
}

// pobrise prvi element s sklada in vrne
// kazalec ne naslednji element
elt * pop(elt *z) {
  if (z==NULL)
    return NULL;

  printf("POP: %s\n", z->ime);

  elt * nZ = z->nasl;
  sprostiElement(z);
  return nZ;
}

// dodajanje na konec seznama
elt * dodajK(elt *z, elt *e) {
  if(z==NULL) {
    return e;
  } else {
    elt *t = z;
    while (t->nasl != NULL)
      t = t->nasl;
    t->nasl=e;
    return z;
  }
}

// iz seznama, ki se zacne pri z pobrise element,
// katerega ime je enako 'ime' in vrne kazalec
// na zacetek popravljenega seznama
elt * brisi(elt *z, char *ime) {
  if (z==NULL) // brisanje iz preznega seznama
    return NULL;

  if (strcmp(z->ime, ime)==0) { // brisem prvi element seznama
    elt *nZ = z->nasl;
    sprostiElement(z);
    return nZ;
  } else { // brisem element znotraj seznama (ni na zacetku)
    elt *t=z;
    while(t->nasl != NULL) {
      if (strcmp(t->nasl->ime,ime)==0) { // sem nasel element, ki ga moram pobrisati
        elt *p = t->nasl;
        t->nasl = t->nasl->nasl;
        sprostiElement(p);
      } else {
        t=t->nasl;
      }
    }
    return z;
  }
}


int main(int argc, char **args) {

  elt *z;   // kazalec na zacetek seznama
  z = NULL; // seznam je prazen

  //elt *e1 = newElement("A");
  //elt *e2 = newElement("B");
  //elt *e3 = newElement("C");
  
  //z = push(z, e1);
  //z = push(z, e2);
  //z = push(z, e3);
  //z = push(z, newElement("D"));
  //z = push(z, newElement("E"));
  //z = push(z, newElement("F"));
  //z = push(z, newElement("G"));

  //z = pop(z);
  //z = pop(z);

  z = dodajK(z, newElement("A"));
  z = dodajK(z, newElement("B"));
  z = dodajK(z, newElement("C"));
  z = dodajK(z, newElement("F"));
  z = dodajK(z, newElement("C"));
  z = dodajK(z, newElement("D"));
  z = brisi(z, "C");

  izpisiSeznam(z);

  return 0;
}
