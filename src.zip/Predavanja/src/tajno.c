#include <stdio.h>

extern int zamik;
extern void kodiraj (char niz[]);

int main(int argc, char *args[]) {
  
  zamik = 5;

  char niz[100];
  printf("Vpisi niz: ");
  scanf("%s", niz);

  kodiraj(niz);
  printf("Kodiran niz: %s\n", niz);

  odkodiraj(niz);
  printf("Odkodiran niz: %s\n", niz);

  return 0;
}
