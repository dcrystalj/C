#include <stdio.h>

// Program izracuna povprecje vpisanih
// ocen. Ocene bere iz tipkovnice, dokler
// uporabnik ne vpise nicle.

int main(int argc, char *args[]) {
  int n=0;      // stevilo prebranih ocen
  int vsota=0;  // vsota prebranih stevil
  int ocena;    // trenutna ocena

  do {
    printf("Vpisi oceno: ");
    scanf("%d", &ocena);

    if (ocena != 0) {
      vsota = vsota + ocena; // vsota += ocena;
      n     = n + 1;         // n++
    } 
  } while (ocena != 0);

  printf("\nPovprecje: %.2f \n", 1.0*vsota/n);
  return 0;
}
