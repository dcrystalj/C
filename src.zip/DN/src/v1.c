/*
Avtor: 63100197

0. Preverba pravilnosti argumentov.
1. Uporabnik preko argumentov doloci operacijo racunala.
2. Pri deljenju naj je rezultat izpisan na "x" decimalk (x = eden od argumentov)
*/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	int x, y, o;

	if(argc >= 4) {
		x = atoi(argv[1]);
		y = atoi(argv[2]);
		o = atoi(argv[3]);
	} else {
		return 1;
	}

	int acc=5;
	if(argc == 5) {
		acc = atoi(argv[4]);
	}

	switch(o) {
		case 1: // +
			printf("%d + %d = %d\n", x, y, x+y);
			break;
		case 2: // -
			printf("%d - %d = %d\n", x, y, x-y);
			break;
		case 3: // *
			printf("%d * %d = %d\n", x, y, x*y);
			break;
		case 4: // /
			printf("%d / %d = %.*f\n", x, y, acc,1.0*x/y);
			break;
	}
	
	return 0;
}
