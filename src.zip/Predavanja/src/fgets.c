// S pomocjo funkcije fgets preberi
// datoteko test.txt in jo izpisi
// na zaslon

#include <stdio.h>

#define N 10

int main(int argc, char *args[]) {
  char niz[N+1];

  FILE *vhod;
  vhod = fopen("test.txt", "r");
 
  if (vhod==NULL) {
    printf("Napaka pri odpiranju datoteke!\n");
    exit(0);
  }

  while ( feof(vhod) == 0) {
    fgets(niz, N, vhod);
    printf("%s", niz);
  }

  fclose(vhod);
  
  return 0;
}
