//
//  main.c
//  PJC vaje
//
//  Created by 63100177
//  Copyright (c) 2012 63100177. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>

// funciton returns the highest value in the given array (int)
int getHighestValue(int *array, int size)
{
    int currentMax = 0;
    for (int i = 0; i < size; i++) {
        if (array[i] > currentMax) {
            currentMax = array[i];
        }
    }
    
    return currentMax;
}

int main(int argc, const char * argv[])
{
    if (argc < 3) {
        printf("You need to pass 2 parameters.");
        return 1;
    }
    
    srand((unsigned int)time(NULL));
    int columnHeight = atoi(argv[2]);
    int countNumbers[10] = {0}; // counts the number of occurences in range of 10 [1,10],[11,20],...,[91,100]
    int countNumbersHeight[10] = {0};
    
    // randomly generate numbers
    for (int i = 0; i < atoi(argv[1]); i++) {
        int generatedNum = rand() % 100 + 1; // a random number in range [1,100]
        countNumbers[(generatedNum - 1) / 10]++;
    }
    
    // calculates the graph parameters
    int highestValue = getHighestValue(countNumbers, 10);
    double stepAmount = (double)highestValue / columnHeight; // get the step value for each point in graph
    for (int i = 0; i < 10; i++) {
        countNumbersHeight[i] = nearbyint(countNumbers[i] / stepAmount);
    }
    
    // paints the graph
    for (int i = 0; i < columnHeight + 1; i++) {
        for (int j = 0; j < 60; j++) {
            if (i == columnHeight) { // final row
                printf("-");
            }
            // each column has 6 spaces, the middle is where the points are painted
            else if ((j % 6 == 2) && (countNumbersHeight[j/6] >= columnHeight - i)) {
                printf("o");
            }
            else { // paint whitespaces in between
                printf(" ");
            }
        }
        printf("\n");
    }
    printf(" 1-10 11-20 21-30 31-40 41-50 51-60 61-70 71-80 81-90 91-100\n");
    
    return 0;
}
