// Program prebere tekstovno datoteko
// 'znak-po-znaku' in jo izpise v 
// drugo datoteko, pri tem pa vse male
// crke spremeni v velike

#include <stdio.h>

int main(int argc, char *args[]) {

  FILE *fVhod, *fIzhod;
  fVhod  = fopen("test.txt",   "r");
  fIzhod = fopen("velike.txt", "w");

  while(feof(fVhod) == 0) {
    int c = fgetc(fVhod);
    
    // male crke spremenimo v velike
    if (c >= 'a' && c <= 'z')
      c = c - ' ';
     
    fputc(c, fIzhod);
  }
  fclose(fIzhod);
  fclose(fVhod);
  return 0;
}
