/*
Navodila:
	Napi�i program,  ki prebere datoteko in v njej pre�teje �tevilo znakov, vrstic in besed
	(podobno, kot dela program wc). Program natan�no stestirajte na razli�nih primerih. Pri 
	tem bodite pozorni na dvojna lo�ila (npr. dva presledka), prazne vrstice na koncu datoteke
	in podobno.
*/
// avtor: 63980314
#include <stdio.h>
#include <stdlib.h>
#include <wctype.h>
#include <string.h>


int main(int argc, char* args[]){
	if(argc == 1 || argc > 2){ //ce je argumentov prevec oz premalo => javi napako in navodila za pravilno uporabo programa
		printf("TxtStat\n----------------------------------------------------------\n"); //header
		
		printf("[ERROR]: The total number of arguements has to be exactly 1.\n");
		printf("Propper formatting: [FILE]*\n*the full path of the file is not needed, if the file is located in the working directory\n");
		
		printf("----------------------------------------------------------\n"); //footer
		return 1;
		
	}else{ //ce je samo 1
		printf("TxtStat - %s\n----------------------------------------------------------\n", args[1]); //header
		FILE* in = fopen(args[1], "r"); //datoteka za branje
		
		if(in == NULL){ //ce datoteka ne obstaja
			printf("[ERROR]: File '%s' could not be found.\n", args[1]);
			printf("----------------------------------------------------------\n"); //footer
			return 1;
		
		}else{
		
			//stevci
			int chars = -1; //za znake
			int nlines = 0; //za vrstice
			int words = 0; //za besede
			
			char* word = (char*) malloc(sizeof(char*)*2); //string v katerega se shrani sestavljena beseda
			int ccount = -1; //stevilo crk/znakov v besedi
			
			char* temp = (char*) malloc(sizeof(char*)*2); //pomozna sprem. za sestavljanje decimalnega stevila
			
			//pomozni sprem.
			int key = 0;
			int num = 0; 
			
			while(!feof(in)){
				int buffer = fgetc(in); //trenutni prebrani znak
				
				if(buffer == '\n'){ //ce je nova vrstica
					nlines++;
					
					if(ccount > -1){ //ce se je sestavljala beseda pred novo vrstico
						word = (char*) realloc(word, sizeof(char*)*2);
						temp = (char*) realloc(word, sizeof(char*)*2);
						
						ccount = -1;
						words++;
						key = 0;
					}
					
				}else{ //ce ni
					chars++;
					
					if(iswalnum(buffer) != 0){ //ce je alfanumericni znak
						if(iswdigit(buffer) != 0) num = 1; //ce je znak stevilo
				
						if(key == 1){ //ce je moznost decimalnega stevila
							if(iswdigit(buffer) != 0){ //ce je znak stevilo => sestavljanje decimalnega stevila
								ccount++;
								word = (char*) malloc(sizeof(char*)*(ccount+2));
								
								strcpy(word, temp);
								word[ccount] = buffer;
								word[ccount+1] = '\0';
								
								temp = (char*) realloc(word, sizeof(char*)*2);
								key = 0;
							
							}else{ //ce ni
								word = (char*) realloc(word, sizeof(char*)*2);
								temp = (char*) realloc(word, sizeof(char*)*2);
						
								ccount = -1;
								words++;
								key = 0;
								num = 0;
							}
							
						}else{ //ce ni
							if(ccount == -1){ //ce je zacetek sestavljanja
							ccount++;
							word = (char*) malloc(sizeof(char*)*2);
						
							}else{ //ce ni
								ccount++;
								word = (char*) realloc(word, sizeof(char*)*(ccount+2));
							}
								word[ccount] = buffer;
								word[ccount+1] = '\0';
						}
							
					}else if(ccount > -1){ //ce ni
						if(buffer == ',' || buffer == '.'){ //odkrivanje moznosti za decimalno stevilo
							ccount++;
							
							//prekopiranje iz word v temp
							temp = (char*) realloc(word, sizeof(char*)*(ccount+2));
							strcpy(temp, word);
						
							temp[ccount] = buffer;
							temp[ccount+1] = '\0';
						
							key = 1;
							num = 0;
							
						}else if(buffer == '-'){ //varovalka, ce je beseda dvodelna(npr. co-founder)
							if(num != 1) word--;
							
						}else{ //ce je drugi znak, ki obicajno nastopa za besedami
							word = (char*) realloc(word, sizeof(char*)*2);
							temp = (char*) realloc(word, sizeof(char*)*2);
							
							ccount = -1;
							words++;
							key = 0;
						}
					}
				}
			}
			printf("Number of characters: %d\nNumber of lines: %d\nNumber of words: %d\n", chars, nlines, words);
			fclose(in);
		}
	}
	printf("----------------------------------------------------------\n"); //footer
	return 0;
}
