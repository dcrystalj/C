// avtor: 63080314

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define W 79
#define H 25

#define A(i,j) blok[W*i+j]

void zmnozi(int *A, int *B, int wA, int hA, int wB){
int i, j, k;
	int mat=0;
	for(i=0; i<hA; i++) {
		for(j=0; j<wB; j++) {
			for(k=0, mat=0; k<wA; k++) {
				//printf("%d  \n",A[i+k]);
				mat +=A[i*wA+k] * B[k*wB+j];//(*(A+i*hA+k)) * (*(B+k*wB+j));
			}
			printf("%d ", mat);
		}
		printf("\n");
	}
}


int main(int argc, char **args) {
	FILE *A, *B;
	A=fopen(args[1], "r"); 
	B=fopen(args[2], "r"); 
	if (A ==NULL && B ==NULL) {
		printf("Napaka pri odpiranju datoteke");
		return 1;
	}

	int wA, hA, wB, hB;
	fscanf(A, "%d%d", &hA, &wA);
	fscanf(B, "%d%d", &hB, &wB);
	//char locila[] = " \n";
	int i,j;

	int **zaslonA =(int**) malloc(hA*sizeof(int *));
  	int *blokA = (int *) malloc(hA*wA*sizeof(int));
  	for(i=0; i<hA; i++)
   		zaslonA[i] = blokA + wA*i*sizeof(int);

	int **zaslonB =(int**) malloc(hB*sizeof(int *));
  	int *blokB = (int *) malloc(hB*wB*sizeof(int));
  	for(i=0; i<hB; i++)
   		zaslonB[i] = blokB + wB*i*sizeof(int);

	i=0; j=0;
	int stevilka=0;
	for(i=0; i<hA; i++) {
		for(j=0; j<wA; j++) {
			fscanf(A, "%d", &stevilka);
			//printf("kam: i> %d j>%d\n",i,j);
			blokA[wA*i+j]=stevilka;
		}
	}

	for(i=0; i<hB; i++) {
		for(j=0; j<wB; j++) {
			fscanf(B, "%d", &stevilka);
			//printf("kam: i> %d j>%d  %d\n",i,j,stevilka);
			blokB[wB*i+j]= stevilka;
		}
	}

	fclose(A); fclose(B);

	printf("Matrika A\n");
	for(i=0; i<hA; i++) {
		for(j = 0; j<wA; j++) {
			printf("%d ", blokA[wA*i+j]);
		}
		printf("\n");
	}

	printf("Matrika B\n");
	for(i=0; i<hB; i++) {
		for(j=0; j<wB; j++) {
			printf("%d ", blokB[wB*i+j],i,j);
		}
		printf("\n");
	}


	printf("\nMatrika C\n");
	zmnozi(blokA, blokB, wA, hA, wB);


	//printf("$ %d \n\n",blokB[4*1+2]);
	/*
	while(fgets(vrstica, sizeof(vrstica), A) != NULL){	
	
		i++;
	}
*/
	printf("\n");

  	
  	//for(i=0; i<hA; i++)
    //	free(zaslonA[i]);
  	//for(i=0; i<hB; i++)
    	//free(zaslonB[i]);
  	//free(zaslonA);
	//free(zaslonB);
	free(zaslonA[0]);
  	free(zaslonA);
	free(zaslonB[0]);
  	free(zaslonB);
 
	return 0;
}
