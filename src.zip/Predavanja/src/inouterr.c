#include <stdio.h>

int main(int argc, char **args) {
  char niz[100];
   
  while (!feof(stdin)) {
    fscanf(stdin, "%s", niz);
    fprintf(stderr, niz);
  }
}
