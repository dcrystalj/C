#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include<string.h>

// avtor: 63100057

void vsezmage(unsigned long long resitve[])
{
	// za navpicno
	long long n = 2113665;
	// za vodoravno 
	long long v=15;
	
	int stevec=0;
	for(int i=0; i < 7; i++)
	{
		
		for(int k=0; k < 4; k++)
		{
			resitve[stevec]=v << k;
			resitve[stevec+28]= n << 7*k;
			stevec++;
			//printf("%lld \n",resitve[stevec-1]);
			//printf("                                  %lld \n",resitve[stevec-1 + 28]);
		}
		v = v << 7;
		n = n <<1;
	}
	long long pl=2130440;
	long long pd = 16843009;
	for(int i=0; i < 4; i++)
	{
		for(int k=0; k < 4; k++)
		{
			resitve[stevec+28]=pl << k;
			resitve[stevec+44]=pd << k;
			stevec++;
			//printf("%lld \n",resitve[stevec-1]);
			//printf("                                  %lld \n",resitve[stevec-1 + 16]);
		}
		pl = pl << 7;
		pd = pd <<7;
	}
		
}

void izpis(unsigned long long maska,unsigned long long polje)
{
	for(int i=0; i < 49; i++)
	{
		if(i % 7 == 0)
		{
			printf("\n");
		}
		if(maska & (long long)1<<i)
		{
			
			if(polje & (long long)1<<i)
			{
				printf("%c ",'X');
			}
			else
			{
				printf("%c ",'O');
			}
		}
		else
		{
			printf("%c ",'-');
		}
		
	}
}


int main(int argc, char *args[]) {

	unsigned long long resitve[88];
	vsezmage(resitve);
	

	unsigned int igralec=0;
	unsigned long long maska=0;
	unsigned long long polje=0;
	char x[3];
	int napake=0;
	int izbira=1;
	long long m=1;
	int zmaga=0;
	izpis(maska,polje);
	while(1)
	{
		int a;
		int b;
		for(int naprej=0; izbira==1 && naprej < 1; )
		{
			scanf("\n%s",x);
			if(x[0] >= '1' && x[0] <= '7' && x[1] >= '1' && x[1] <= '7' )
			{
				a = (int)(x[0])-49;
				b=(int)(x[1])-49;
				
				if((maska & m<<(a + b*7)) == 0)
				{
					maska = maska | m<<(a + b*7);
					
					polje = polje | (long long)1<<(a + b*7);
					naprej=1;
				}
				else
				{
					napake++;
					printf("Polje zasedeno\n");
				}
			}
			else
			{
				napake++;
				printf("Napacen vnos\n");
			}
			if(napake>= 3)
			{
				zmaga=1;
				igralec =0;
				naprej=1;
			}
			
		}
		
		
		// racunalnik 
		int nev1=0;
		int nev2 =0;

		// za uporabnika pribliuek zmagi 
		int max1=0;
		int max2=0;
		int index1=0, index2=0;
		for(int i=0; i < 88; i++)
		{
			
			long long priigrano2;
			long long priigrano = maska & resitve[i];
			priigrano2 = priigrano & ~polje;
			priigrano = priigrano & polje;
			
			//printf(" %lld-%lld",priigrano,maska&resitve[i]);
			int st=0;
			int st2=0;
			
			if(priigrano2 != 0 && priigrano2 == (maska & resitve[i]))
			{
				//printf(" %d ",i);
				for(int k=0; k < 49; k++)
				{
					if(priigrano2 & (long long)1<<k)
					{
						st2++;
						//printf("%d ",st2);
					}
				}
			}
			if(priigrano != 0 && priigrano == (maska & resitve[i]))
			{
				//printf("ok");
				for(int k=0; k < 49; k++)
				{
					if(priigrano & (long long)1<<k)
					{
						st++;
						//printf("j%d ",st);
					}
				}
			}
			if(st > max1)
			{
				max1 = st;
				index1=i;
			}
			if(st2 > max2)
			{
				max2 = st2;
				index2=i;
			}
		}
		//printf("%d > %d", max1,max2);
		if(max1 == 4)
		{
			zmaga=1;
			igralec = 1;
		}
		if(max2 == 4)
		{
			zmaga=1;
			igralec =0;
		}

		if(zmaga==1)
		{
			
			if(!igralec)
			{
				printf("izgubili ste");
				break;
			}
			else
			{
				izpis(maska,polje);
				printf("zmagali ste");
				break;
			}
		}
		
		if(izbira == 1 && zmaga == 0)
		{
			if(max1 > max2)
			{
				printf("blokira ");
				for(int i=49; i >= 0; i--)
				{
					if( (long long)1<<i & resitve[index1] && !(maska &  (long long)1<<i))
					{
						maska = maska | (long long)1<<i;
						polje = polje | (long long)0<<i;
						break;
					}
				}
			}
			else
			{
				printf("napada ");
				int f=0;
				for(int i=49; i >= 0; i--)
				{
					if( (long long)1<<i & resitve[index2] && !(maska &  (long long)1<<i))
					{
						//printf(" %d %lld",index2, resitve[index2]);
						maska = maska | (long long) 1<<i;
						polje = polje | (long long) 0<<i;
						f++;
						break;
					}
				}
				if(!f)
				{
					printf("blefira ");
					for(int i=0; i < 88; i++)
					{
						if((resitve[i] & ~maska) == resitve[i])
						{
							for(int h=0; h < 49; h++)
							{
								if( (long long)1<<h & resitve[i] && !(maska &  (long long)1<<i))
								{
									maska = maska | (long long) 1<<i;
									polje = polje | (long long) 0<<i;
									break;
								}
							}
						}
					}
				}
			}
			izpis(maska,polje);
		}
		izbira *=-1;
		
		printf("\n");
		
	}


return 0;
}
