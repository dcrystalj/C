#include <stdio.h>

int main(int argc, char **args) {

  // char a[10];

  // printf("%p, %p\n", a, &a[0]);

  int a[10];

  int *pa;
  pa = a;

  *pa = 3;  
  printf("%d\n", a[0]);

  pa[7] = 15;
  printf("%d\n", a[7]);



  return 0;
}
