#include <stdio.h>
#include <math.h>

void vDvojisko(int x, char dvojisko[]) {
  // ce dobim niclo, takoj vrnem rezultat
  if (x==0) {
    dvojisko[0]='0'; dvojisko[1]='\0';
    return;
  }
   
  int i=0;

  // preverjal bom 'prisotnost' posameznih bitov,
  // zacel bom pri najvecjem
  int testBit = pow(2, 30);


  // najprej poiscem prvi (najvecji) prizgani bit (sicer
  // bi dobil na zacetku veliko nicel)
  while((testBit>0) && (!(testBit & x))) 
    testBit = testBit >> 1;

  // grem po posameznih bitih in za vsak prizgan bit
  // dodam '1', ce je bit ugasnjen, pa dodam '0'
  while (testBit>0) {
      dvojisko[i++]=(testBit & x) ? '1' : '0';
      testBit = testBit >> 1;
  }

  // niz se pravilno zakljucim
  dvojisko[i]='\0';
}  

int vDesetisko(char dvojisko[]) {
  int rezultat=0;
  int i=0;
  
  // uporabim isti princip kot pri resitvi naloge
  // 4.II iz abC (pretvorba iz niza v int); edina
  // razlika: tu namesto z 10 mnozim z 2 (saj pretvarjam
  // iz dvojiskega sistema)
  for(i=0; i<strlen(dvojisko); i++) 
    rezultat = 2 * rezultat + (dvojisko[i] - '0');   

  return rezultat;
}

main() {
  char dvojisko[33];

  int x=42;
 
  vDvojisko(x, dvojisko);
  printf("%d(10) = %s(2) \n", x, dvojisko);

  int y = vDesetisko(dvojisko);
  printf("%s(2) = %d(10) \n", dvojisko, y);
}
