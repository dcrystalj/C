#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

typedef struct tock{
	char ime[6];
	float x;
	float y;
}point;

void izpisi(point *a, int size){
	point *p;
	p=a;
	int i=0;
	while(i<size){
		printf("%s %f %f\n",(*p).ime,(*p).x,(*p).y);
		p++;
		i++;
	}
}

float length(point a){
	return (float)sqrt((double)(a.x*a.x + a.y*a.y));
}

float absf(float a){
	return (a<0) ? -a : a;
}

int primerjava(const void *x,const void *y){
	float l1 = length(*(point*)x);
	float l2 = length(*(point*)y);
	if(l1==l2){
		return 0;
	}
	return l1<l2 ? -1 : 1;
}


int main(int argc, char *args[]){
	
	if(argc!=3){
		printf("Neveljavno stevilo argumentov\n");
		exit(0);
	}

	FILE *f;
	f=fopen(args[1],"r");
	if(f==NULL){
		printf("Ne najdem datoteke\n");
		exit(0);
	}
	char s[41];
	fgets(s,40,f);
	
	int size=atoi(s);
	point *tab;
	tab = (point*) malloc(size*sizeof(point));
	point *pt;
	pt=tab;

	float x,y;
	char name[6];
	int i=0;
	while(feof(f)==0 && i<size){
		fscanf(f,"%s %f %f",name,&x,&y);
		strcpy((*pt).ime,name);
		(*pt).x=x;
		(*pt).y=y;
		//printf("%s %f %f\n",(*pt).ime,(*pt).x,(*pt).y);
		pt++;
		i++; 
	}
	fclose(f);
	pt=tab;
	//izpisi(tab,size);
	int j;
	point sub;
	if(strcmp(args[2],"ABS")==0){
		for(i=0;i<size;i++){
			for(j=i+1;j<size;j++){
				sub.x=tab[i].x-tab[j].x;
				sub.y=tab[i].y-tab[j].y;
				if(length(sub) < 1.002 * absf(length(tab[i])-length(tab[j]))){
					printf("%s - %s\n",tab[i].ime,tab[j].ime);
				}
			}
		}
	}else if(strcmp(args[2],"UREDI")==0){
		qsort(tab,size,sizeof(point),primerjava);
		float l;
		int rez;
		char s[20];
		for(int i=0;i<size;i++){
			l=length(tab[i]);
			if(l > 1.0){
				rez=sprintf(s,"%s - (%.2f, %.2f)",tab[i].ime,tab[i].x,tab[i].y);
				printf("%-20s%f\n",s,l);
			}
		}
	}

	free(tab);
	fclose(f);
	return 0;
}
