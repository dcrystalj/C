#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **args) {
  FILE *fIN  = fopen("e:\\medo.bmp",  "rb");
  FILE *fOUT = fopen("e:\\medoX.bmp", "wb");

  if (fIN == NULL || fOUT == NULL) {
    fprintf(stderr, "Napaka");
    exit(1);
  }

  int d; // bzte, ki ga preberem iz datoteke
  while((d=fgetc(fIN)) != EOF) {
    fputc(d, fOUT);
  }

  fclose(fIN);
  fclose(fOUT);
}
