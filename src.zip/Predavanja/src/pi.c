#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Racunanje stevila PI s pomocjo
// generatorja nakljucnih stevil.
//
// Opis: n-krat generiram par 
// (x,y) z lastnostjo 0 <= x, y <= 1
// in preverim, ali lezi v kroznem
// izseku s   polmerom 1; na podlagi 
// dejstva, da je razmerje med pari, ki 
// le�ijo v krogu in tistimi, ki ne lezijo,
// PI : 4, izracunam PI.
int main(int argc, char *args[]) {

  int n=100000000;
  int vKrogu = 0;

  int i;
  for(i=0; i<n; i++) {
    // generiram dve nakljucni realni stevili
    float x = (float) rand() / RAND_MAX;
    float y = (float) rand() / RAND_MAX;

    // ali par lezi v krogu?
    if (x*x + y*y <= 1)
      vKrogu++;
  }  

  printf("Pi = %.10f \n", 4.0*vKrogu/n);
 
  return 0;
}
