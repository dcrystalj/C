// avtor: 63110464

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* args[]) {
	int i = atoi(args[1]);
	int j;
	int vsota = 0;
	int n = 0;
	for (j = 0; j < 256; j++) {
		int stevilo = j;
		int stevec = 0;
		while (stevilo) {
			stevec += (stevilo & 1);
			stevilo = stevilo >> 1;
		}
		if (stevec == i) {
			int st = j;
			int k = 7;
			char cifre[7];
			while (st) {	
				cifre[k--] = st&1;
				st = st >> 1;
			}
			for (k = 0; k < 8; k++) {
				printf("%d", cifre[k]);
			}
			printf(" = %d\n", j);
			vsota += j;
			n++;
		}
	}
	printf("i = %d, n = %d, vsota = %d\n", i, n, vsota);

	return 0;
}
