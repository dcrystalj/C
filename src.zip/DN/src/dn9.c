#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// avtor: 63110423
typedef struct {
  char *ime;
  char *priimek;
  char *telefon;
} oseba; 


int osebaCmp(oseba a, oseba b, int atr) {
	if (atr==0) {
		return strncmp(a.ime, b.ime, 100);
	}
	if (atr==1) {
		return strncmp(a.priimek, b.priimek, 100);
	}
	else {
		return strncmp(a.telefon, b.telefon, 100);
	}
}


int CmpIme(const void *a, const void *b) {
	oseba* aa= (oseba*) a;
	oseba* bb= (oseba*) b;
	return strncmp( (*aa).ime, (*bb).ime, 100);
}
int CmpPriimek(const void *a, const void *b) {
	oseba* aa= (oseba*) a;
	oseba* bb= (oseba*) b;
	return strncmp( (*aa).priimek, (*bb).priimek, 100);
}

void Zdruzi(oseba* arr[],int spMeja,int sredina,int zgMeja, int attr, int steviloOseb){

    int i,m,k,l;
	oseba* temp[steviloOseb];

    l=spMeja;
    i=spMeja;
    m=sredina+1;

    while((l<=sredina)&&(m<=zgMeja)){
         if(osebaCmp(*arr[l], *arr[m], attr)<=0){
             temp[i]=arr[l];
             l++;
         }
         else{
             temp[i]=arr[m];
             m++;
         }
         i++;
    }

    if(l>sredina){
         for(k=m;k<=zgMeja;k++){
             temp[i]=arr[k];
             i++;
         }
    }
    else{
         for(k=l;k<=sredina;k++){
             temp[i]=arr[k];
             i++;
         }
    }
   
    for(k=spMeja;k<=zgMeja;k++){
         arr[k]=temp[k];
    }
}

void Deli(oseba* arr[],int spMeja,int zgMeja, int attr, int steviloOseb ){

    int sredina = 0;

    if(spMeja < zgMeja){
         sredina=(spMeja + zgMeja) / 2;
         Deli (arr,spMeja,sredina, attr, steviloOseb);
         Deli (arr,sredina + 1,zgMeja, attr, steviloOseb);
         Zdruzi (arr, spMeja, sredina, zgMeja, attr, steviloOseb);
    }
}

void MergeSort(int steviloOseb, oseba os[], int attr) {
	oseba* tabela[steviloOseb];
	int ik;
	for (ik=0;ik<steviloOseb;ik++) {
		tabela[ik]=os + ik;
	}
	Deli(tabela, 0, steviloOseb-1, attr, steviloOseb);
	oseba rezerva[steviloOseb];
	for (ik=0;ik<steviloOseb;ik++) rezerva[ik]=*tabela[ik];
	for (ik=0;ik<steviloOseb;ik++) os[ik]=rezerva[ik];
}

void shuffle(oseba *array, int n)
{
    int i;
	for (i = 0; i < n - 1; i++) {
	  int j = i + rand() / (RAND_MAX / (n - i) + 1);
	  oseba t = array[j];
	  array[j] = array[i];
	  array[i] = t;
	}
}


int main(int argc, char *args[]) {
	FILE *vhod;
	vhod=fopen(args[1], "r");
	if (vhod ==NULL) {
		printf("Napaka pri odpiranju datoteke");
		return 1;
	}
	char line[100];
	int i=0;
	int steviloOseb;
	if (fgets ( line, sizeof line, vhod) == NULL) return 2;
	if (sscanf(line, "%d", &steviloOseb) == 0) return 3;
	int skupno=0;
	oseba osebe[steviloOseb];
	while (fgets(line,120,vhod)) {
		char *token;
        token = strtok(line,":");
		int length=strlen(token)+1;
		osebe[i].ime=malloc (length);
        strcpy(osebe[i].ime,token);
		osebe[i].ime[length]='\0';
		skupno+=length * sizeof(char);
		printf("%s, %dB\n", token, length);

        token = strtok(NULL,":");
		length=strlen(token)+1;
		osebe[i].priimek=malloc (length);
		strcpy(osebe[i].priimek,token);
		osebe[i].priimek[length]='\0';
		skupno+=length;
		printf("%s, %dB\n", token, length);

		token = strtok(NULL,"\n");
		length=strlen(token)+1;
		osebe[i].telefon=malloc (length);
		strcpy(osebe[i].telefon,token);
		osebe[i].telefon[length]='\0';
		skupno+=length;
		printf("%s, %dB\n", token, length);
        i++;
    }
	fclose(vhod);
	printf("\nNizi v osebah: %dB\n", skupno);
	printf("Tabela oseb: %dB\n", (int) sizeof(osebe));
	printf("Skupaj: %dB\n\n", skupno+(int)sizeof(osebe));
	for (i =0;i<steviloOseb;i++) printf("%s %s: %s\n", osebe[i].ime,osebe[i].priimek,osebe[i].telefon);
	int izbira=0;

	do {
	printf("\nKaj zdaj?\n1-mergesort po imenu, 2-mergesort po priimku, 3-mergesort po telefonski st.\n4-quicksort po imenu, 5-quicksort po priimku, 6-mesaj, >6-izhod\n");
	scanf("%d", &izbira);
	if (izbira<1) continue;
	switch (izbira) {
		case 1: MergeSort(steviloOseb, osebe,0);
				break;
		case 2: MergeSort(steviloOseb, osebe,1);
				break;
		case 3: MergeSort(steviloOseb, osebe,2);
				break;
		case 4: qsort(osebe, steviloOseb, sizeof(oseba), CmpIme);
				break;
		case 5: qsort(osebe, steviloOseb, sizeof(oseba), CmpPriimek);
				break;
		case 6: shuffle(osebe, steviloOseb);
				break;
		}
	for (i =0;i<steviloOseb;i++) printf("%s %s: %s\n", osebe[i].ime,osebe[i].priimek,osebe[i].telefon);
	}
//quicksort bi moral biti nestabilen, pa ni. skrivnostno.
	while (izbira<7);
	return 0;
}
