// Progam izpise vse argumente, 
// s katerimi je bil pognan

#include <stdio.h>

int main(int argc, char *args[]) {

  // Ime programa
  printf("Ime programa: %s \n", args[0]);

  int i;
  for(i=1; i<argc; i++) {
    printf("Argument %d: %s\n", i, args[i]);
  }
}
