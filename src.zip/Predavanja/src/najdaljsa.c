#include <stdio.h>
#include <string.h>

int main(int argc, char *args[]) {
  char tr[100];
  char najdaljsa[100]="";

  do {
    fgets(tr, 100, stdin);

    if (strcmp(tr, "\n")==0) 
      break;

    if (strlen(tr) > strlen(najdaljsa))
      strcpy(najdaljsa, tr);


  } while (1);

  printf("Najdaljsa: %s", najdaljsa);
  return 0;
}
