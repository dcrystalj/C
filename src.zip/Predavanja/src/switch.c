int main(int argc, char *args[]) {

  int i;
  scanf("%d", &i);

  switch (i) {
    case 10: printf("Odlicno!\n");  break;
    case 9 : printf("Prav dobro!\n"); break;
    case 8 : printf("Prav dobro!\n");break;
    case 7 : printf("Dobro!\n");     break;
    case 6 : printf("Zadostno!\n");break;
    case 5 : printf("Nezadostno!\n");break;
    default: printf("Ni ocena!\n");
  }

  return 0;
}
