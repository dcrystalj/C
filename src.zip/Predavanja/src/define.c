// komentar

int j=10;

#define N 100

#define min(A,B) ((A)<(B)?(A):(B))

#define forever for(;;)

#define dprint(e) printf(#e" = %.2f\n", (double)e)

int minimum(int x, int y) {
  return (x<y ? x : y);
}

main() {
  // komentar
  printf("%d\n", N);

  char *niz1="abc";
  char *niz2="xzy";

  int a=5; int b=7;
  printf("%d\n", min(a,b));
  printf("%c\n", min('f','d'));
  printf("%c\n", min('f','d'));
  printf("%s\n", min(niz1,niz2));

  printf("min(%d,%d)=%d\n", a,b, minimum(a++,b++));
  printf("min(%d,%d)=%d\n", a,b, min(a++,b++));


  dprint(a/b);

}
