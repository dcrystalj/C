#include <stdio.h>
#include <stdlib.h>
#define V 7
#define Z 4

int polje[V][V];
char znak[] = {'X','O'};
int poskusi[2];

void zbrisi() {
	int i,j;
	for(i=0; i<V; i++) {
		for(j=0; j<V; j++) {
			polje[i][j] = ' ';
		}
	}
}

void izpisi() {
	int i;
	printf(	" A B C D E F G \n");
	printf(	"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n", 218,196,194,196,194,196,194,196,194,196,194,196,194,196,191);

	for(i=0; i<V; i++) {
		printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%d\n", 179,polje[i][0],179,polje[i][1],179,polje[i][2],179,polje[i][3],179,polje[i][4],179,polje[i][5],179,polje[i][6],179, i+1);

		if(i != 6) printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n", 195,196,197,196,197,196,197,196,197,196,197,196,197,196,180);
	}

	printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n", 192,196,193,196,193,196,193,196,193,196,193,196,193,196,217);
}

int jeZasedeno(int x, int y) {
	printf("x=%d y=%d polje[y][x] = %c\n",x,y, polje[y-1][x-1]);
	if(polje[y-1][x-1] == 'X' || polje[y-1][x-1] == 'O') return 1;
	return 0;
}

int zmaga() {
	int i,j;

	// Preveri vrstice //
	for(i=0; i<V; i++) {
		for(j=0; j<V-3; j++) {
			if(polje[i][0+j] == 'X' && polje[i][1+j] == 'X' && polje[i][2+j] == 'X' && polje[i][3+j] == 'X') return 1;
			if(polje[i][0+j] == 'O' && polje[i][1+j] == 'O' && polje[i][2+j] == 'O' && polje[i][3+j] == 'O') return 1;
		}
	}
	
	// Preveri stolpce //
	for(i=0; i<V; i++) {
		for(j=0; j<V-3; j++) {
			if(polje[0+j][i] == 'X' && polje[1+j][i] == 'X' && polje[2+j][i] == 'X' && polje[3+j][i] == 'X') return 1;
			if(polje[0+j][i] == 'O' && polje[1+j][i] == 'O' && polje[2+j][i] == 'O' && polje[3+j][i] == 'O') return 1;
		}
	}

	// Backslash diagonale \    //
	int n=3;

	for(i=0; i<V-3; i++) {
		for(j=0; j<V-n; j++) {
			if(polje[0+j][0+j+i] == 'X' && polje[1+j][1+j+i] == 'X' && polje[2+j][2+j+i] == 'X' && polje[3+j][3+j+i] == 'X') return 1;
			if(polje[0+j][0+j+i] == 'O' && polje[1+j][1+j+i] == 'O' && polje[2+j][2+j+i] == 'O' && polje[3+j][3+j+i] == 'O') return 1;
		}
		n++;
	}
	
	n=3;

	for(i=0; i<V-3; i++) {
		for(j=0; j<V-n; j++) {
			if(polje[0+j+i][0+j] == 'X' && polje[1+j+i][1+j] == 'X' && polje[2+j+i][2+j] == 'X' && polje[3+j+i][3+j] == 'X') return 1;
			if(polje[0+j+i][0+j] == 'O' && polje[1+j+i][1+j] == 'O' && polje[2+j+i][2+j] == 'O' && polje[3+j+i][3+j] == 'O') return 1;
		}
		n++;
	}

	// Slash diagonale /   //
	n=3;
	for(i=0; i<V-3; i++) {
		for(j=0; j<V-n; j++) {
			if(polje[6-i-j][0+j] == 'X' && polje[5-i-j][1+j] == 'X' && polje[4-i-j][2+j] == 'X' && polje[3-j-i][3+j] == 'X') return 1;
			if(polje[6-i-j][0+j] == 'O' && polje[5-i-j][1+j] == 'O' && polje[4-i-j][2+j] == 'O' && polje[3-j-i][3+j] == 'O') return 1;
		}
		n++;
	}

	n=3;

	for(i=0; i<V-3; i++) {
		for(j=0; j<V-n; j++) {
			if(polje[0+j+i][6-j] == 'X' && polje[1+j+i][5-j] == 'X' && polje[2+j+i][4-j] == 'X' && polje[3+j+i][3-j] == 'X') return 1;
			if(polje[0+j+i][6-j] == 'O' && polje[1+j+i][5-j] == 'O' && polje[2+j+i][4-j] == 'O' && polje[3+j+i][3-j] == 'O') return 1;
		}
		n++;
	}
	
	return 0;
}

int main(int argc, char* args[]) {
	zbrisi();
	izpisi();

	poskusi[0]=0;
	poskusi[1]=0;
	int stevec = 0;
	int igralec = 0;
	int x = 0;
	int y = 0;
	char a = ' ';

	while(stevec < V*V) {

		// PREDVIDEVAM DA JE NAPAKA TUKAJ //
		while(1) {
			printf("Poteza (igralec %d): ", igralec);
      int kolikoPrebranih = 0;
      do {
        kolikoPrebranih = scanf("%c %d", &a, &y);
      } while (kolikoPrebranih != 2);

			// ta blok if stavkov omogoca, da je vnesena crka lahko mala ali velika
			if(a >= 65 && a<=71) {
				x = a-64;
				printf("crka=%d x=%d y=%d\n", a,x,y);
			} else if(a >= 97 && a <= 103) {
				x = a-96;
				printf("crka=%d x=%d y=%d\n", a,x,y);
			}
			
			if(jeZasedeno(x,y)) {
				printf("Polje je zasedeno! Poskusi znova.\n");
				poskusi[igralec]++;
				printf("Preostali poskusi: Igralec0 - %d , Igralec1 - %d\n", 3-poskusi[0], 3-poskusi[1]);
				
				if(poskusi[0] == 3 || poskusi[1] == 3) {
					printf("\nIgralec%d je naredil prevec napak. Zmagal je igralec%d\n", igralec, 1-igralec);
					exit(0);
				}
			} else {
				break;
			}
		} 

		// TU SE MOJ BLOK Z NAPAKO KONCA //

		if(x > 0 && y > 0 && x <= V && y <=V) {
			polje[y-1][x-1] = znak[igralec];
		} else {
			printf("Crke morajo biti med A in B, stevila pa med 1 in 7!\n");
			continue;
		}
		

		izpisi();

		if(zmaga()) {
			printf("Zmagal je igralec %d! Cestitke!\n", igralec);
			break;
		}
		
		igralec = 1-igralec;
		stevec++;
	}
	
	if(!zmaga()) printf("Ni zmagovalca!\n"); 

	return 0;
}
