/*
 * krizciKrozci.c
 *
 *  Created on: 23. nov. 2012
 *      Author: (63110341)
 */


#include <stdio.h>
#include <stdlib.h>

#define H 3
#define W 3
#define ZAPOREDNIH_ZA_ZMAGO 3
#define ST_IGRALCEV	2
#define MAX_NEPRAVILNIH_POTEZ 3

char plosca[H][W];
char znakIgralec[ST_IGRALCEV] = {'X','O'};
int stevecNepravilnihPotez[ST_IGRALCEV];


void ponastavi()
{
	int i,j;
	
	for (i = 0; i < H; i++)
	{
		for (j = 0; j < W; j++)
		{
			plosca[i][j] = ' ';
		}
	}
	
	for (i = 0; i<ST_IGRALCEV; i++)
	{
		stevecNepravilnihPotez[i] = 0;
	}
	
}

void izpisiPlosco()
{
	int i,j;
	
	printf("\n");
	
	int k;
	for (k=0; k<4*W+1; k++)
	{
		printf("#");
	}
	
	printf("\n");
	
	
	for (i = 0; i < H; i++)
	{
		printf("#");
		for (j = 0; j < W; j++)
		{
			
			if (j != 0)
			{
				printf("|");
			}
			
			printf(" %c ",plosca[i][j]);
			
			
			
		}
		
		printf("#");
		
		printf("\n");
		
		
		if (i<H-1)
		{
			printf("#");
			
			
			
			for (k=0; k<W; k++)
			{
				if (k != 0)
				{
					printf("+");
				}
				
				printf("---");
			}
			
			printf("#");
			
			printf("\n");
		}
		
		
	}
	
	for (k=0; k<4*W+1; k++)
	{
		printf("#");
	}
	
	printf("\n");
	
}


int preveriZmago(int igralec)
{
	int i,j;
	
	int zaporednih = 0;
	
	//preveri vrstice
	for (i = 0; i < H; i++)
	{
		zaporednih = 0;
		for (j = 0; j < W; j++)
		{
			if (plosca[i][j] == znakIgralec[igralec])
			{
				zaporednih++;
				
				if (zaporednih == ZAPOREDNIH_ZA_ZMAGO)
				{
					return 1;
				}
				
			}
			else
			{
				zaporednih = 0;
			}
		}
	}
	
	
	//preveri stolpce
	for (j = 0; j < W; j++)
	{
		zaporednih = 0;
		for (i = 0; i < H; i++)
		{
			if (plosca[i][j] == znakIgralec[igralec])
			{
				zaporednih++;
				
				if (zaporednih == ZAPOREDNIH_ZA_ZMAGO)
				{
					return 1;
				}
				
			}
			else
			{
				zaporednih = 0;
			}
		}
	}
	
	
	
	//preveri diagonale
	int jj,ii;
	
	//dol-desno | zgornje
	for (jj=0; jj<W; jj++)
	{
		//printf("jj: %d\n",jj);
		
		zaporednih = 0;
		
		j=jj;
		i=0;
		
		while(i<H && j<W)
		{
			if (plosca[i][j] == znakIgralec[igralec])
			{
				zaporednih++;
				
				if (zaporednih == ZAPOREDNIH_ZA_ZMAGO)
				{
					return 1;
				}
				
			}
			else
			{
				zaporednih = 0;
			}
			
			i++;
			j++;
		}
	}
	
	//dol-desno | spodnje
	for (ii=0; ii<H; ii++)
	{
		//printf("ii: %d\n",ii);
		
		zaporednih = 0;
		
		j=0;
		i=ii;
		
		while(i<H && j<W)
		{
			if (plosca[i][j] == znakIgralec[igralec])
			{
				zaporednih++;
				
				if (zaporednih == ZAPOREDNIH_ZA_ZMAGO)
				{
					return 1;
				}
				
			}
			else
			{
				zaporednih = 0;
			}
			
			i++;
			j++;
		}
	}
	
	
	//dol-levo | zgornje
	for (jj=0; jj<W; jj++)
	{
		//printf("jj: %d\n",jj);
		
		zaporednih = 0;
		
		j=jj;
		i=0;
		
		while(i<H && j<W && i>=0 && j>=0)
		{
			if (plosca[i][j] == znakIgralec[igralec])
			{
				zaporednih++;
				
				if (zaporednih == ZAPOREDNIH_ZA_ZMAGO)
				{
					return 1;
				}
				
			}
			else
			{
				zaporednih = 0;
			}
			
			i++;
			j--;
		}
	}
	
	
	//dol-levo | spodnje
	for (ii=0; ii<H; ii++)
	{
		//printf("ii: %d\n",ii);
		
		zaporednih = 0;
		
		j=W-1;
		i=ii;
		
		while(i<H && j<W && i>=0 && j>=0)
		{
			if (plosca[i][j] == znakIgralec[igralec])
			{
				zaporednih++;
				
				if (zaporednih == ZAPOREDNIH_ZA_ZMAGO)
				{
					return 1;
				}
				
			}
			else
			{
				zaporednih = 0;
			}
			
			i++;
			j--;
		}
	}
	
	
	
	return 0;
}



int main(int argc, char **argv) {
	
	
	ponastavi();
	izpisiPlosco();
	
	
	int poteza = 0;
	int igralec = poteza % ST_IGRALCEV;
	
	do
	{
		int x,y;
		int legalnaPoteza = 0;
		
		do
		{
			printf("Igralec '%c'> ",znakIgralec[igralec]);
			scanf("%d",&x);
			scanf("%d",&y);
			
			//pretvori v rac. koordinate
			x--;
			y--;
			
			if (x>=0 && x<W && y>=0 && y<H && plosca[y][x] == ' ')
			{
				//legalna poteza
				legalnaPoteza = 1;
				
				plosca[y][x] = znakIgralec[igralec];
				
				
				izpisiPlosco();
				
				
				if (preveriZmago(igralec))
				{
					printf("Zmagal je igralec '%c'!\n",znakIgralec[igralec]);
					return 0;
				}
				
				
			}
			else
			{
				//ilegalna poteza
				legalnaPoteza = 0;
				
				stevecNepravilnihPotez[igralec]++;
				
				if (stevecNepravilnihPotez[igralec] == MAX_NEPRAVILNIH_POTEZ)
				{
					printf("Igralec '%c' je izgubil zaradi prevec nepravilnih potez!\n",znakIgralec[igralec]);
					return 0;
				}
				
				printf("Nepravilna poteza!\n");
				
				
				
			}
			
		}
		while(!legalnaPoteza);
		
		poteza++;
		igralec = poteza % ST_IGRALCEV;
		
	}
	while(poteza < H*W);

	
	printf("Prislo je do remija.\n");
	
	return 0;
}




