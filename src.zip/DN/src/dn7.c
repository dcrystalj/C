/*
Navodila:
	Napi�i program, ki izpi�e uporabni�ka imena (login name) in lupino (zadnji podatek v vrstici)
	uporabnikov linux sistema, ki imajo UID ve�ji ali enak n in manj�i ali enak m (n in m sta prva
	dva argumenta programa). Uporabnike sistema naj program prebere iz datoteke, katere ime je podano
	v tretjem argumentu. 

	Primer: ob klicu "izpisi 100 102 passwd" naj program izpi�e

		libuuid - /bin/sh
		syslog - /bin/false
		mysql - /bin/false

	Za razbijanje vrstice na posamezna polja uporabi funkcijo strtok. Podatke o format passwd datoteke,
	si lahko preberete, na primer, tu.
*/
// avtor: 63980314
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//funkcija, ki razbije prebrano vrstico na tokene in izpise username in shell, ce se UID ujema s pogoji
//opombe: rahlo hroscata, nekatere shell-e noce pravilno izpisati(vzrok: napacno postavljeni pointerji(?))
void checkUser(char* line, int min, int max){
	char seperator[] = ":"; //locila, ki lahko nastopajo v vrstici
	
	int flag = 0; //pom. sprem., ki doloca, ali je izpolnjen pogoj
	int counter = 1; //stevec
	
	char* username;
	char* shell;
	
	char* temp = strtok(line, seperator); //string v katerega se pisejo tokeni
	
	while(temp != NULL){ //razbijanje stringa na tokene
		if(counter == 1){ //na zacetku se shrani username
			username = (char*) malloc(strlen(temp)+1);
			strcpy(username, temp);
		
		}else if(counter == 3){ //UID preverjanje
			int UID = atoi(temp);
			
			if(UID >= min && UID <= max){
				flag = 1;
			}
		
		}else if(counter == 7){ //shranjevanje shell-a
			shell = (char*) malloc(strlen(temp)+1);
			strcpy(shell, temp);
		}
		
		temp = strtok(NULL, seperator);
		counter++;
	}
	
	if(flag == 1){ //ce je pogoj izpolnjen => izpisi "username - shell" od uporabnika, ki smo ga preverjali
		printf("%s - %s\n", username, shell);
	}
}

int main(int argc, char* args[]){
	if(argc == 1 || argc > 4){ //ce je argumentov prevec oz premalo => javi napako in navodila za pravilno uporabo programa
		printf("UsrFltr\n----------------------------------------------------------\n"); //header
		
		printf("[ERROR]: The total number of arguements has to be exactly 1.\n");
		printf("Propper formatting: [UID_min][UID_max][FILE]*\n");
		printf("*the full path of the file is not needed, if the file is located in the working directory\n");
		
		printf("----------------------------------------------------------\n"); //footer
		return 1;
	
	}else{ //ce so 3
		printf("UsrFltr - %s\n----------------------------------------------------------\n", args[3]); //header
		
		int min = atoi(args[1]); //spodnja meja
		int max = atoi(args[2]); //zgornja meja
		FILE* in = fopen(args[3], "r"); //vhodna datoteka
		
		char* line = (char*) malloc(sizeof(char*)*2); //string v katerem se sestavlja in hrani vrstica
		
		int ccount = -1; //st prebranih znakov
		int end = 1; //pom. sprem., ki doloca konec vrstice
		
		int buffer; //sprem. v katero se shrani prebrani znak
		while(!feof(in)){
			buffer = fgetc(in); //trenutni prebrani znak
			
			if(buffer == '\n'){ //ce nastopi nova vrstica
				checkUser(line, min, max); //preverjanje pogoja z/brez izpisovanja
				
				line = (char*) realloc(line, sizeof(char*)*2); //alociranje pomn za string velikosti 2 (1 znak + '\0')
				ccount = -1;
				end = 0;
				
			}else{ //sestavljanje vrstice
				ccount++;
				
				line = (char*) realloc(line, sizeof(char*)*(ccount+2)); //vecanje pomn.
				line[ccount] = buffer; //tren. znak
				line[ccount+1] = '\0'; //konec stringa
				
				end = 1;
			}
		}
		
		if(end == 1){ //dodatno preverjanje, ce se datoteka konca brez nove vrstice
			checkUser(line, min, max);
		}
		
		fclose(in);
	}
	printf("----------------------------------------------------------\n"); //footer
	return 0;
}
