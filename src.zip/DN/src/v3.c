// avtor: 63110222

#include <stdio.h>

#define N 10

int main(int argc, char *args[])
{
	char niz[N+1];
	FILE *vhod;
	vhod = fopen("mandela.txt", "r");
	if(!vhod) return 1;
	int c = 0;
	while(feof(vhod) == 0)
	{
		fgets(niz, N, vhod);
		int i;
		for(i = 0; i < N; i++) 
		{
			if(niz[i] == ' ' || niz[i] == ',' || niz[i] == '.' || niz[i] == '(' || niz[i] == ')')
			{
					niz[i] = ' ';
					c = 1;
			}
			else if(c != 0 && i != N-1)
			{
				niz[i-1] = '\n';
				c = 0;
			}
		}
		printf("%s", niz);
	}
	fclose(vhod);
	return 0;
}
