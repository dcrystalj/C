int main(int argc, char **args) {
  printf("i=%d\n", i);
}
