/*
 * stetje.c
 *
 *  Created on: 16. nov. 2012
 *      Author: (63110341)
 */

#include <stdio.h>
#include <stdlib.h>

int indexPojavitve(int c)
{
	int index = (c-'0');
	
	if (index >= 0 && index < 10)
	{
		return index;
	}
	
	return -1 ;
}

int main(int argc, char **argv) {
	
	
	if (argc < 2)
	{
		printf("Ni dovolj argumentov!\n");
		exit(-1);
	}
	
	/// odpri datoteko
	char * imeDatoteke = argv[1];
	
	FILE * f;
	f = fopen(imeDatoteke,"r");
	
	
	/// init pojavitve
	int pojavitve[10];
	
	int i;
	for (i=0; i<10; i++)
	{
		pojavitve[i] = 0;
	}
	
	
	
	//beri
	int c;
	while ( (c=fgetc(f)) != EOF )
	{
		int indexPojav = indexPojavitve(c);
		
		//DEBUG//printf("%c	%d	%d\n",c,c,indexPojav);
		
		if (indexPojav != -1)
		{
			pojavitve[indexPojav]++;
		}
	}
	
	
	
	//izpisi
	for (i = 0; i < 10; ++i) 
	{
		if (i)
		{
			printf(",");
		}
		
		printf("%d=%d",i,pojavitve[i]);
		
	}
	
	printf("\n");
	
	
	// zapri za sabo
	fclose(f);
	
	
	
	return 0;
}
