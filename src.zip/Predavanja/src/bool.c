// dobimo tip bool in vrednosti 
// true/false
#include <stdbool.h>

main() {
  bool a=false;

  printf("%s\n", a ? "TRUE" : "FALSE");
}
