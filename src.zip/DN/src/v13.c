//
//  main.c
//  PJC vaje
//
//  Created by Andrej Cesen
//  Copyright (c) 2012 Andrej Cesen. All rights reserved.
//
//  The program converts the specified BMP image to shades of grey.
//

#include <stdio.h>
#include <stdlib.h>

#define N 3000

#pragma pack(2)

typedef struct {
    unsigned char type[2]; // 0x4D42
    unsigned int file_size;
    unsigned short int reserved1;
    unsigned short int reserved2;
    unsigned int offset; // offset in bytes to bitmap data
} file_header;

#pragma pack()

typedef struct {
    unsigned int header_size;
    int bitmap_width;
    int bitmap_height;
    unsigned short int number_of_planes;
    unsigned short int bits_per_pixel;
    unsigned int compression_type;
    unsigned int image_size; // the size of the raw bitmap data
    int horizontal_resolution;
    int vertical_resolution;
    unsigned int number_of_colors;
    unsigned int number_of_important_colors;
} information_header;

int main(int argc, const char * argv[])
{
    if (argc != 2) {
        printf("Usage: ImageFilePath\n");
        return 1;
    }
    
    FILE *fp;
    if ((fp = fopen(argv[1], "rb+")) == NULL) { // tries to open the specified file
        printf("Error when opening the file.\n");
        return 1;
    }
    
    // allocates space for the file header and reads it
    file_header *inputFileHeader;
    if ((inputFileHeader = malloc(sizeof(*inputFileHeader))) == NULL) {
        printf("Out of avaliable memory.\n");
        return 1;
    }
    fread(inputFileHeader, sizeof(*inputFileHeader), 1, fp);
    
    // allocates space for the information header and reads it
    information_header *inputInformationHeader;
    if ((inputInformationHeader = malloc(sizeof(*inputInformationHeader))) == NULL) {
        printf("Out of avaliable memory.\n");
        return 1;
    }
    fread(inputInformationHeader, sizeof(*inputInformationHeader), 1, fp);
    
    // converts the picture to grey shades (S, S, S); S = (R+G+B) / 3
    fseek(fp, inputFileHeader->offset, SEEK_SET);
    unsigned char *buffer = malloc(N);
    int count = N - N % 3; // a multiple of 3 bytes per pixel
    size_t read; // number of bytes read (elements of size 1B)
    fpos_t position; // used to remember the position of where to start writing
    do {
        fgetpos(fp, &position);
        read = fread(buffer, 1, count, fp);
        for (int i = 0; i < read; i += 3) {
            unsigned char greyValue = (buffer[i] + buffer[i + 1] + buffer[i + 2]) / 3;
            buffer[i] = greyValue;
            buffer[i + 1] = greyValue;
            buffer[i + 2] = greyValue;
        }
        
        fsetpos(fp, &position);
        fwrite(buffer, 1, read, fp);
    } while(read > 0);
    
    return 0;
}
