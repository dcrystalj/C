// avtor: 63980186

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

int jeTrikotno(int i)
{	
	double x = sqrt(8*i + 1);
	int y = (int)x;
	double r = x - (double)y;	

	if (r == 0.0)
		return 1;
	return 0;	
}

int main(int argc, char *args[])
{
	FILE *f;
	f = fopen(args[1], "r");
	char beseda[30];
	if(f == NULL)
	{
		printf("datoteka ne obstaja");
		exit(1);
	}
	
	int vsotaZnakov = 0;
	int trikotneBesede = 0;
    while(!feof(f))
	{
		int i;
		fscanf(f, "%s", beseda);
        for(i=0; i<strlen(beseda); i++)
			vsotaZnakov += beseda[i]-'A'+1;
		
		if(jeTrikotno(vsotaZnakov))
			trikotneBesede++;

		vsotaZnakov = 0;
    }

	printf("%d\n", trikotneBesede);	

	return 0;	
}






