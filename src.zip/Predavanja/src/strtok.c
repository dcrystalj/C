#include <stdio.h>
#include <string.h>

int main(int argc, char *args) {

  char vrstica[] = "abc:def:xzy";
  char locila[]  = ":";
  char *rezultat;

  rezultat = strtok(vrstica, locila);
  while (rezultat != NULL) {
    printf("%s\n", rezultat);
    rezultat = strtok(NULL, locila);
  }

  return 0;
}
