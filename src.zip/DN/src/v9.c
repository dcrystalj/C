// avtor: 63980186

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
typedef struct {
  char *ime;
  char *priimek;
  char *telefon;
} oseba;

oseba newOseba(int ime, int priimek, int cifra)
{
	oseba o;
	o.ime = malloc(ime+1);
	o.priimek = malloc(priimek+1);
	o.telefon = malloc(cifra+1);

	return o;
}

int main(int argc, char *args[])
{	
	FILE *f = fopen(args[1], "r");
	if(f == NULL)
		exit(1);

	char vrstica[100];
	char locila[] = ":\n";


	int velikost;
 	fscanf(f, "%d\n", &velikost);	
    oseba *o = malloc(velikost*(sizeof(oseba)));

	int velikostPomnilnika = velikost*sizeof(oseba);


	char *ime, *priimek, *telefon;
	int i = 0;	
	while(fgets(vrstica, sizeof(vrstica), f) != NULL)
	{	
		//printf("%s", vrstica);
		ime = strtok(vrstica, locila);
		priimek = strtok(NULL, locila);
		telefon = strtok(NULL, locila);

		//printf("%s %s %s\n", ime, priimek, telefon);	

		o[i] = newOseba(strlen(ime), strlen(priimek), strlen(telefon));
		strcpy(o[i].ime, ime);
		strcpy(o[i].priimek, priimek);
		strcpy(o[i].telefon, telefon);

		velikostPomnilnika += strlen(o[i].ime) + strlen(o[i].priimek)  + strlen(o[i].telefon) + 3;		
		i++;
	}

	printf("Pomnilnik: %d\n", velikostPomnilnika);

	for(int k=0; k<i; k++) {
      printf("%s %s %s\n", o[k].ime, o[k].priimek, o[k].telefon);
	}

    return 0;
}
