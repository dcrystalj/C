#include <limits.h>

main() {

  printf("%d %d %d\n",
    sizeof(short), 
    sizeof(int), 
    sizeof(long));

  printf("INT_MAX: %d\n", INT_MAX);

  int s[3]={3};
}
