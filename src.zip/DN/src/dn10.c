// avtor: 63110167

#include <stdio.h>
#include <stdlib.h>

typedef struct element {
    int x, y;
    int val;
    struct element *next;
} element;

element *newElement (int x, int y, int val) {
    element *temp = (element *)malloc(sizeof(element));
    temp->x = x;
    temp->y = y;
    temp->val = val;
    temp->next = NULL;
    return temp;
}

void writeOut(element *start) {
    while(start != NULL) {
        printf("%d %d %d\n", start->x, start->y, start->val);
        start = start->next;
    }
}

element *addSorted (element *start, int x, int y, int val) {
    if (start == NULL)
        return start = newElement(x, y, val);
    else if ((start->y > y) || (start->y == y && start->x > x)) {
        element *temp = newElement(x, y, val);
        temp->next = start;
        return temp;
    }

    element *i = start;
    while(i->next != NULL && ( (i->next->y < y) || (i->next->y == y && i->next->x < x) ) ) i = i->next;

    element *temp = newElement(x, y, val);
    temp->next = i->next;
    i->next = temp;
    return start;
}

element *readMatrix (char *path) {
    FILE *f = fopen(path, "r");
    element *start = NULL;
    int x, y, val;

    if (f == NULL) {
        printf("Ne najdem datoteke: %s\n", path);
        exit(1);
    }
    
    while(!feof(f)) {
        fscanf(f, "%d %d %d\n", &y, &x, &val);
        start = addSorted(start, y, x, val);
    }

    return start;
}

element *sum(element *i, element *j) {
    element *start = NULL;

    while(i != NULL) {
        while(j != NULL) {
            if(i->x == j->x && i->y == j->y) {
                if(i->val + j->val) start = addSorted(start, i->x, i->y, i->val + j->val);
                j = j->next;
                break;
            }
            else if( (j->y > i->y) || (j->y == i->y && j->x > i->y) ) {
                start = addSorted(start, i->x, i->y, i->val);
                break;
            }
            start = addSorted(start, j->x, j->y, j->val);
            j = j->next;
        }
        i = i->next;
    }

    return start;
}

int main (int argc, char *argv[]) {
    element *first = readMatrix(argv[1]);
    element *second = readMatrix(argv[2]);

    element *third = sum(first, second);
    writeOut(third);
    return 0;
}
