// Napisi program, ki izpise tiste studentske izdelke, ki se po dolzini
// oddane kode za vec kot  50% razlikujejo od povprecja dolzin oddanih nalog

// Opomba: podatke o oddanih nalogah naj program crpa iz izpisa "ls -la"


#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *args[]) {

  char vrstica[200];


  FILE *files;
  files = fopen("e:\\files.txt", "r");
  if (files == NULL) {
    printf("Datoteka ne obstaja!\n");
    exit(1);
  }

  char n1[30], n2[30], n3[30];
  int s1, s2;
  int vsota = 0, n = 0;
  while (!feof(files)) {
    int p = fscanf(files, "%s%d%s%s%d", n1, &s1, n2, n3, &s2);
    if (p == 5) {
      fgets(vrstica, 200, files);
      vsota = vsota + s2; n++;
    }    
  }
  fclose(files);

  int pov = vsota / n;
  printf("Povprecna dolzina: %d \n", pov);

  files = fopen("e:\\files.txt", "r");
  while (!feof(files)) {
    int p = fscanf(files, "%s%d%s%s%d", n1, &s1, n2, n3, &s2);
    if (p==5) {
      int razlika = abs(pov - s2);
      fgets(vrstica, 200, files);
      if (razlika > 0.5 * pov) {
        printf("%d %s",s2, vrstica);
      } 
    }    
  }
  fclose(files);

}
