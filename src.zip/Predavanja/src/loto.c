#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <stdbool.h>

#define N 7

int tabela[N];
int koliko=0;  // koliko stevil je ze v tabeli

bool jeZeVTabeli(int stevilo) {
  int i;
 
  for(i=0; i<koliko; i++) {
    if (tabela[i]==stevilo)
      return true;
  }
  return false;
}

void uredi(int a[], int n) {
  int i, j;
  for(i=0; i<n-1; i++) 
    for(j=0; j<n-i-1; j++) 
      if (a[j] > a[j+1]) {
        a[j]  = a[j] ^ a[j+1];
        a[j+1]= a[j] ^ a[j+1];
        a[j]  = a[j] ^ a[j+1];
      }
} 

int primerjava(const void *x, const void *y){
  return *(int*)y - *(int *)x;
}

// Program generira N nakljucnih stevil med
// 1 in 39 (uporaba: loto listek)
int main(int argc, char *args[]) {

  srand(time(NULL));

  int i;
  for(i=1; i<=N; i++) {
    int x = rand() % 39 + 1;
    if (!jeZeVTabeli(x))
      tabela[koliko++]=x;
    else i--;
  }
 
  //uredi(tabela, N);

  qsort(tabela, N, sizeof(int), primerjava); 

  for(i=1; i<=N; i++)
    printf("%d \n", tabela[i-1]);

  return 0;
}
