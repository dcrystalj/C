#include "moj.h"
#include <stdio.h>

void izpisi(char *niz) {
  int i;
  for(i=0; i<N; i++) {
    printf("%d - %s\n", i, niz);
  }
}