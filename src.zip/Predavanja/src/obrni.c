// Prebere niz iz tipkovnice
// in ga izpise v obratni smeri

#include <stdio.h>

#if SYSTEM==WINDOWS
  #define lib win.h
#elif SYSTEM==MAC
  #define lib mac.h
#endif

#include <lib>

#undef DEBUG

int main(int argc, char *args[]) {

  char niz[11];

  scanf("%10s", niz);
  printf("Vpisali ste niz '%s'. \n", niz);

  int i;
  printf("Obrnjen niz: ");
  for(i=strlen(niz)-1; i>=0; i--) {
#ifdef DEBUG
    printf("%d", i);
#endif
    printf("%c", niz[i]);
  }
  printf("\n");

  return 0;
}
