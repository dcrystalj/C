#include <stdio.h>
#include <stdlib.h>

char * preberiBesedo(void) {
  char *niz = malloc(100);

  scanf("%s", niz);
  return niz;
}


int main(int argc, char **args) {
  char *beseda;
  for(int i=0; i<5; i++) {
    beseda = preberiBesedo();
    printf("%s\n", beseda);
  }

  return 0;
}
