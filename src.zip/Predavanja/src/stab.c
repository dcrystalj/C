#include <stdio.h>

void i(int a[][5]) {
  printf("%d\n", a[1][1]);
}

int main(int argc, char **args) {
  int a[][5]={1,2,3,4,5,6};

  i(a);
}
