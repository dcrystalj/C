#include <stdlib.h>
#include <stdio.h>
#include <time.h>

// Program generira 7 nakljucnih stevil med
// 1 in 39 (uporaba: loto listek)
int main(int argc, char *args[]) {

  // najvecje nakljucno stevilo
  printf("RAND_MAX = %d \n", RAND_MAX);


  srand(time(NULL));

  int i;
  for(i=1; i<=7; i++) {
    int x = rand() % 39 + 1;
    printf("%d \n", x);
  }
  return 0;
}
