#include <stdio.h>

int main(int argc, char **args) {

  int x=13;

  int *p;
  // p = (int *) 0x12ff84;
  p = &x;
  *p = 42;

  printf("%d\n", x);
  

  return 0;
}
