#include "moj.h"
#include <stdio.h>

int main(int argc, char **args) {

  char niz[100];
  printf("Vpisi niz, ki ga bom izpisal %d-krat: ", N);
  scanf("%s", niz);
  
  izpisi(niz);
}