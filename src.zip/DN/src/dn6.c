/**
 * @file    dn06.c
 * @author  63110222
 * @date    18. 11. 2012
 * @brief   sesta domaca naloga pri PJC
 *
 *  Igra i4 v vrsto� se igra na igralni deski velikosti 7x7.
 *	Igrata dva igralca, eden z rde�imi, drugi z belimi figurami.
 *	Igralca izmeni�no polagata svoje figure na poljubno prazno
 *	polje na igralni deski. Zmaga tisti igralec, ki prvi postavi 4
 *	svoje figure  eno zraven druge v vodoravni, navpi�ni ali digonalni smeri.
 */

#include <stdio.h>
#include <stdlib.h>

#define N 7
#define E 4

/****************************************
 *
 *  Umetna inteligenca
 *
 ***************************************/
int checkRow(char f[][N], int n, char t)
{
    int i, c = 0;
    for(i = 0; i < N; i++)
    {
        if(f[n][i] == t)
        {
            c++;
            if(c == 2)
            {
                if(i+1 < N && f[n][i+1] == ' ' &&
                   i+2 < N && f[n][i+2] == t)
                    return i+1;
                else if(i-2 >= 0 && f[n][i-2] == ' ' &&
                        i-3 >= 0 && f[n][i-3] == t)
                    return i-2;
            }
            else if(c == 3)
            {
                if(i+1 < N && f[n][i+1] == ' ')
                    return i+1;
                else if(i-3 >= 0 && f[n][i-3] == ' ')
                    return i-3;
                c = 0;
            }
        }
        else c = 0;
    }
    return -1;
}

int checkCol(char f[][N], int n, char t)
{
    int i, c = 0;
    for(i = 0; i < N; i++)
    {
        if(f[i][n] == t)
        {
            c++;
            if(c == 2)
            {
                if(i+1 < N && f[i+1][n] == ' ' &&
                   i+2 < N && f[i+2][n] == t)
                    return i+1;
                else if(i-2 >= 0 && f[i-2][n] == ' ' &&
                        i-3 >= 0 && f[i-3][n] == t)
                    return i-2;
            }
            else if(c == 3)
            {
                if(i+1 < N && f[i+1][n] == ' ')
                    return i+1;
                else if(i-3 >= 0 && f[i-3][n] == ' ')
                    return i-3;
                c = 0;
            }
        }
        else c = 0;
    }
    return -1;
}

/* \ po x-u */
int checkDiagonalDownX(char f[][N], int n, char t)
{
    int i, c = 0;
    for(i = 0; i < N; i++)
    {
        if(f[i][i+n] == t)
        {
            c++;
            if(c == 2)
            {
                if(i+1 < N && i+n+1 < N && f[i+1][n+i+1] == ' ' &&
                   i+2 < N && i+n+2 < N && f[i+2][n+i+2] == t)
                    return i+1;
                else if(i-2 >= 0 && i+n-2 < N && f[i-2][n+i-2] == ' ' &&
                        i-3 >= 0 && i+n-3 < N && f[i-3][n+i-3] == t)
                    return i-2;
            }
            else if(c == 3)
            {

                if(i+1 < N && i+n+1 < N && f[i+1][n+i+1] == ' ')
                    return i+1; // vrne y
                else if(i-3 >= 0 && i+n-3 >= 0 && f[i-3][n+i-3] == ' ')
                    return i-3;
                c = 0;
            }
        }
        else c = 0;
    }
    return -1;
}

/* \ po y-u */
int checkDiagonalDownY(char f[][N], int n, char t)
{
    int i, c = 0;
    for(i = 0; i < N; i++)
    {
        if(f[i+n][i] == t)
        {
            c++;
            if(c == 2)
            {
                if(i+1 < N && i+n+1 < N && f[n+i+1][i+1] == ' ' &&
                   i+2 < N && i+n+2 < N && f[n+i+2][i+2] == t)
                    return i+1;
                else if(i-2 >= 0 && i+n-2 < N && f[n+i-2][i-2] == ' ' &&
                        i-3 >= 0 && i+n-3 < N && f[n+i-3][i-3] == t)
                    return i-2;
            }
            else if(c == 3)
            {
                if(i+1 < N && i+n+1 < N && f[n+i+1][i+1] == ' ')
                    return i+1;
                else if(i-3 >= 0 && i+n-3 >= 0 && f[n+i-3][i-3] == ' ')
                    return i-3;
                c = 0;
            }
        }
        else c = 0;
    }
    return -1;
}

/* / po x-u - vraca y */
int checkDiagonalUpX(char f[][N], int n, char t)
{
    int i, c = 0;
    for(i = 0; i < N; i++)
    {
        if(f[N-1-i][i+n] == t)
        {
            c++;
            if(c == 2)
            {
                if(i+1 < N && N-2-i >= 0 && f[N-2-i][n+i+1] == ' ' &&
                   i+2 < N && N-3-i >= 0 && f[N-3-i][n+i+2] == t)
                    return N-2-i;
                else if(i-2 >= 0 && N+1-i < N && f[N+1-i][i-2] == ' ' &&
                        i-3 >= 0 && N+2-i < N && f[N+2-i][i-3] == t)
                    return N+1-i;
            }
            else if(c == 3)
            {
                if(i+1 < N && N-2-i >= 0 && f[N-2-i][n+i+1] == ' ')
                    return N-2-i;
                else if(i-3 >= 0 && N+2-i < N && f[N+2-i][n+i-3] == ' ')
                    return N+2-i;
                c = 0;
            }
        }
        else c = 0;
    }
    return -1;
}

/* / po y-u - vraca x - sprejme 5,4,3 */
int checkDiagonalUpY(char f[][N], int n, char t)
{
    int i, c = 0;
    for(i = 0; i < N; i++)
    {
        if(f[n-i][i] == t)
        {
            c++;
            if(c == 2)
            {
                if(i+1 < N && n-i-1 >= 0 && f[n-i-1][i+1] == ' ' &&
                   i+2 < N && n-i-2 >= 0 && f[n-i-2][i+2] == t)
                    return i+1;
                else if(i-2 >= 0 && n-i+2 < N && f[n-i+2][i-2] == ' ' &&
                        i-3 >= 0 && n-i+3 < N && f[n-i+3][i-3] == t)
                    return i-2;
            }
            else if(c == 3)
            {
                if(i+1 < N && n-i-1 < N && f[n-i-1][i+1] == ' ')
                    return i+1;
                else if(i-3 >= 0 && n-i+3 >= 0 && f[n-i+3][i-3] == ' ')
                    return i-3;
                c = 0;
            }
        }
        else c = 0;
    }
    return -1;
}

/****************************************
 *
 *  Igra
 *
 ***************************************/

void showField(char f[][N])
{
    int i, j;
    for(i = 0; i < N; i++)
    {
        for(j = 0; j < N; j++)
            printf("%c", f[i][j]);
        printf("\n");
    }
}

void initField(char f[][N])
{
    int i, j;
    for(i = 0; i < N; i++)
        for(j = 0; j < N; j++)
            f[i][j] = ' ';
}

int gameWin(char f[][N], int x, int y, int p)
{
    int c, i, m, mx, my;
    char b;
    if(p%2) b = 'x';
    else b = 'o';

    /* horizontalno iskanje */
    c = 0;
    for(i = 0; i < N; i++)
    {
        if(f[y][i] == b)
        {
            c++;
            if(c == E) return 1;
        }
        else c = 0;
    }

    /* vertikalno iskanje */
    c = 0;
    for(i = 0; i < N; i++)
    {
        if(f[i][x] == b)
        {
            c++;
            if(c == E) return 1;
        }
        else c = 0;
    }

    /*************/

    if(x < y) m = x;
    else m = y;
    mx = x - m;
    my = y - m;

    /* diagonalno iskanje (navzdol) */
    c = 0;
    while(mx < N && my < N)
    {
        if(f[my][mx] == b)
        {
            c++;
            if(c == E) return 1;
        }
        else c = 0;
        mx++; my++;
    }

    /*************/

    if(x < N-y-1) m = x;
    else m = y;
    mx = x - m;
    my = y + m;

    /* diagonalno iskanje (navzgor) */
    c = 0;
    while(mx < N && my >= 0)
    {
        if(f[my][mx] == b)
        {
            c++;
            if(c == E) return 1;
        }
        else c = 0;
        mx++; my--;
    }

    return 0;
}

int main(int argc, char *args[])
{
    srand(time(NULL));
    char field[N][N], p1, p2;
    int x, y, curr = rand(), p = curr%2, endTurn = 0, end = 49, player, s;
    int illCount[] = {0,0};
    initField(field);
    printf("1 ali 2 igralca? ");
    scanf("%d", &player);
    player--;
    printf("stil: (1)R/B ali (2)x/o? ");
    scanf("%d", &s);
    switch(s)
    {
        case 1: p1 = 'R'; p2 = 'B'; break;
        default: p1 = 'x'; p2 = 'o';
    }
    printf("Zacne igralec %d\n", curr%2+1);
    if(p > 0) end++;
    while(p < end)
    {
        curr = p%2;
        printf("Poteza (igralec %d):", curr+1);
        if(curr == 0 || player)
        {
            scanf("%1d %1d", &x, &y);
            x--; y--;
        }
        else
        {
            int n, r = 0, c = 0, dd = 0, du = 0;
            x = -1; y = -1; endTurn = 0;
            /*win*/
            for(n =  0; n < N; n++)
            {
                r = checkRow(field, n, p1);
                if(r > -1)
                {
                    x = r; y = n;
                    endTurn++;
                    break;
                }
                c = checkCol(field, n, p1);
                if(c > -1)
                {
                    x = n; y = c;
                    endTurn++;
                    break;
                }
            }
            if(!endTurn)
            {
                for(n = 0; n < N/2+1; n++)
                {
                    dd = checkDiagonalDownX(field, n, p1);
                    if(dd > -1)
                    {
                        x = dd; y = n+x;
                        endTurn++;
                        break;
                    }
                    dd = checkDiagonalDownY(field, n, p1);
                    if(dd > -1)
                    {
                        y = dd; x = n+y;
                        endTurn++;
                        break;
                    }
                    du = checkDiagonalUpX(field, n, p1);
                    if(du > -1)
                    {
                        y = du; x = n+y;
                        endTurn++;
                        break;
                    }
                }
            }
            if(!endTurn)
            {
                for(n = N/2; n < N-1; n++)
                {
                    du = checkDiagonalUpY(field, n, p1);
                    if(du > -1)
                    {
                        x = du; y = n-x;
                        endTurn++;
                        break;
                    }
                }
            }

            /*block*/
            if(!endTurn)
            {
                for(n =  0; n < N; n++)
                {
                    r = checkRow(field, n, p2);
                    if(r > -1)
                    {
                        y = n; x = r;
                        endTurn++;
                        break;
                    }
                    c = checkCol(field, n, p2);
                    if(c > -1)
                    {
                        y = c; x = n;
                        endTurn++;
                        break;
                    }
                }
            }
            if(!endTurn)
            {
                for(n = 0; n < N/2+1; n++)
                {
                    dd = checkDiagonalDownX(field, n, p2);
                    if(dd > -1)
                    {
                        y = dd; x = n+y;
                        endTurn++;
                        break;
                    }
                    dd = checkDiagonalDownY(field, n, p2);
                    if(dd > -1)
                    {
                        x = dd; y = n+x;
                        endTurn++;
                        break;
                    }
                    du = checkDiagonalUpX(field, n, p2);
                    if(du > -1)
                    {
                        y = du; x = n+y;
                        endTurn++;
                        break;
                    }
                }
            }

            if(!endTurn)
            {
                for(n = N/2; n < N-1; n++)
                {
                    du = checkDiagonalUpY(field, n, p2);
                    if(du > -1)
                    {
                        x = du; y = n-x;
                        endTurn++;
                        break;
                    }
                }
            }

            if(x < 0 || y < 0)
            {
                srand(time(NULL));
                do {
                    x = rand() % N;
                    y = rand() % N;
                } while(x < 0 || x >= N || y < 0 || y >= N || field[y][x] != ' ');
            }
            printf("%d %d\n", x+1, y+1);
        }
        if(x < 0 || x >= N || y < 0 || y >= N || field[y][x] != ' ')
        {
            printf("Nelegalna poteza!\n");
            if(field[y][x] != ' ')
            {
                illCount[curr]++;
                printf("%c", 7);
                printf("Napaka! (%d/3)\n", illCount[curr]);
                if(illCount[curr] == 3)
                {
                    printf("Igralec %d je izgubil igro.\n", curr+1);
                    return 0;
                }
            }
            continue;
        }
        if(curr) field[y][x] = p1;
        else field[y][x] = p2;
        if(gameWin(field, x, y, p))
        {
            printf("Zmagal je igralec %d!\nCestitam!\n", curr+1);
            return 0;
        }
        showField(field);
        p++;
    }
    printf("Ni zmagovalca!\n");
    return 0;
}

