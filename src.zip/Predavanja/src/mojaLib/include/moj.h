#define N 10

void izpisi(char *);