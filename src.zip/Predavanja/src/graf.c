#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define H 24
#define W 80


char zaslon[H][W];

// sprazni tabelo
void brisi(void) {
  int i,j;

  for(i=0; i<H; i++)
    for(j=0; j<W; j++)
      zaslon[i][j] = ' ';
}

// izpise tabelo na zaslon
void izpisi(void) {
  int i,j;

  for(i=0; i<H; i++) {
    for(j=0; j<W; j++)
      printf("%c", zaslon[H-i-1][j]);
    if (W<80)
      printf("\n");
  }
}

void narisiKoordinatniSistem(void) {
  int i, j;
  for(i=0; i<H; i++)
    zaslon[i][W/2]= '|';
  for(j=0; j<W; j++)
    zaslon[H/2][j]='-';
  
  zaslon[H/2][W/2]='+';
}

void funkcija(void) {

  double x1=-3.14;
  double x2= 3.14;
  double y1=-1;
  double y2= 1;

  int i,j;

  for(i=0; i<W; i++) {
    double x = i*(x2-x1)/W + x1;
    double y = sin(x);
    j =(y-y1)/(y2-y1)*H;

    zaslon[j][i]='*';
  } 
}


int main(int argc, char *args[]) {

  brisi();
  narisiKoordinatniSistem();
  funkcija();
  izpisi();


  return 0;
}
