#include <stdio.h>
#include <stdlib.h>

void uporaba() {
  printf("Uporaba: racunalo x y (x in y sta celi stevili)\n");

  exit(0);
}

// Program izracuna vsoto prvih dveh
// argumentov. Prej preveri, ce sta
// argumenta sploh podana in ce sta 
// res celi stevili.
int main(int argc, char *args[]) {

  if (argc != 3) 
    uporaba();

  // pretvorba iz niza v celo stevilo 
  // brez preverjanje
  // int x = atoi(args[1]);
  // int y = atoi(args[2]);

  // pretvorba s preverjanjem
  int x, y;
  int prviOK  = sscanf(args[1], "%d", &x);
  int drugiOK = sscanf(args[2], "%d", &y);

  if (prviOK!=1 || drugiOK!=1)
    uporaba();

  printf("%d + %d = %d\n", x, y, x+y);

  return 0;
}
