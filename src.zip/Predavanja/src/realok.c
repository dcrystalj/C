#include <stdlib.h>

// poveca velikost tabele t za 1
// n pove velikost tabele pred povecanjem
// funkcija vrne novo tabelo
void realok(int **t, int n) {
  int *nova;
  nova = malloc((n+1)*sizeof(int));

  int i;  
  for(i=0; i<n; i++)
    nova[i] = (*t)[i]; //*(nova+i) = *(t+i);
  
  if (n>0) free(*t);

  *t = nova;
}

int main(int argc, char **args) {
 int *tabela;

 int i;
 for(i=0; i<100; i++) {
   realok(&tabela, i);
   tabela[i] = i;
 } 
}
