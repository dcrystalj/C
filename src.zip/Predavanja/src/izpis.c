// Formatiran izpis s funkcijo printf

#include <stdio.h>

int main(int argc, char *args[]) {

  int x = 5;
  int y = 7;

  printf("%d + %d = %d\n", x, y, x+y);

  return 0;
}
