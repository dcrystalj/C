/*
Navodila:
	Napi�i program za delo s skladom celih �tevil. Sklad implementiraj s pomo�jo tabele.
	Program naj omogo�a operacije push (dodaj na za�etek seznama), pop (pobri�i element 
	na za�etku seznama) ter jePrazen() (vrne 1, �e je sklad prazen in 0 sicer). Velikost 
	sklada je podana v prvem argumentu programa. �e pride do prekora�itve velikosti sklada
	(operacija push, ko je sklad ue poln), naj program le zapiska (beep), operacijo pa naj
	ignorira. Program naj omogo�a internaktivno delo preko naslednjega menija:

		1 ... Dodaj �tevilo na sklad (push)
		2 ... Vzemi in izpi�i �tevilo s sklada (pop)
		3 ... Ali je sklad prazen?
		4 ... Sprazni sklad
		5 ... Izhod iz programa

avtor: 63980314
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void clear(int *stack, int size){ //funkcija, ki izprazni sklad(celega napolni z 0)
	int i;
	for(i = 0; i<size; i++){
		stack[i] = 0;
	}
}

int jePrazen(int *stack, int size){ //funkcija, ki preveri ali je sklad prazen
	int i;
	for(i = 0; i<size; i++){
		if(stack[i] != 0){
			return 0;
		}
	}
	return 1;
}

void push(int *stack, int size, int el){ //funkcija, ki doda element na za�etek sklada(stack[0])
	if(jePrazen(stack, size) == 1){ //ce je prazen
		stack[0] = el;
		printf("Stevilo %d je bilo dodano na sklad.\n--------------\n\n", el);
		
	}else{ //ce ni
		if(stack[size-1] != 0){ //ce je sklad poln
			printf("\a--------------\n\n");
			
		}else{
			int key = 1;
			int i;
			for(i = (size-1); i>=0; i--){ //pomikanje elementov v desno
				if(key == 1){
					if(stack[i] != 0){
						key = 0;
						stack[i+1] = stack[i];
					}
				
				}else{
					stack[i+1] = stack[i];
				}
			}
			stack[0] = el; //dodajanje
			printf("Stevilo %d je bilo dodano na sklad.\n--------------\n\n", el);
		}
	}
}

void pop(int *stack, int size){ //funkcija, ki odstrani element z za�etka sklada(stack[0]) in pomakne vse elemente v levo
	if(jePrazen(stack, size) == 1){ //ce je prazen
		printf("\aSklad je prazen.\n--------------\n\n");
		
	}else{ //ce ni
		int popped = stack[0]; //elem., ki smo ga odstranili
	
		int key = 1; //pomozna sprem.
		int prev = 0; //prejsnji elem.
		int curr = 0; //trenutni elem.
		int i;
		for(i = (size-1); i>=0; i--){ //pomikanje elementov v levo(s tem 2. elem. povozi 1. elem.)
			if(key == 1){
					if(stack[i] != 0){
						key = 0;
						
						prev = stack[i];
						stack[i] = 0;
					}
				
				}else{
					curr = stack[i];
					stack[i] = prev;
					prev = curr;
				}
		}
		printf("Stevilo %d je bilo odvzeto iz sklada.\n--------------\n\n", popped);
	}
}

int main(int argc, char *args[]){
	printf("stack\n----------------------------------------------------------\n"); //header
	
	if(argc != 2){ //ce je argumentov prevec oz premalo => javi napako in navodila za pravilno uporabo programa
		printf("[ERROR]: The total number of arguements has to be exactly 1.\n\n");
		printf("Propper formatting: [stack_size]\n");
		
		printf("----------------------------------------------------------\n"); //footer
		return 1;
		
	}else{ //ce je tocno 1
		char zero[] = "0"; //pomozna sprem. za preverjanje
		int size = atoi(args[1]); //velikost sklada
		
		if(strcmp(args[1], zero) == 0 || size < 0){ //ce je velikost <= 0
			printf("[ERROR]: The size of the stack has to be atleast 1.\n");
			printf("----------------------------------------------------------\n"); //footer
			return 1;
			
		}else if(size == 0){ //ce args[1] ni stevilo
			printf("[ERROR]: '%s' is not a number.\n", args[1]);
			printf("----------------------------------------------------------\n"); //footer
			return 1;
			
		}else{ //sicer
			int stack[size]; //sklad
			clear(stack, size); //na zacetku postavi vse elemente v tabeli na 0(ga izprazni)
			
			int cmd = 0; //izbor
			int num = 0; //stevilo, ki se bo nalozilo na sklad
			while(1){
				printf("	1 ... Dodaj stevilo na sklad (push)\n");
				printf("	2 ... Vzemi in izpisi stevilo s sklada (pop)\n");
				printf("	3 ... Ali je sklad prazen?\n");
				printf("	4 ... Sprazni sklad\n");
				printf("	5 ... Izhod iz programa\n\nIzbira: ");
				
				scanf("%d", &cmd); //branje izbora
				
				if(cmd == 1){ //dodajanje
					printf("Vnesite celo stevilo: ");
					scanf("%d", &num);
					
					push(stack, size, num);
					
				}else if(cmd == 2){ //odstranjevanje + izpis(ce je sklad prazen, to javi in zapiska)
					pop(stack, size);
					
				}else if(cmd == 3){ //preverjanje, ce je prazen
					if(jePrazen(stack, size) == 1){
						printf("Sklad je prazen.\n--------------\n\n");
						
					}else{
						printf("Sklad ni prazen.\n--------------\n\n");
					}
					
				}else if(cmd == 4){ //praznenje
					clear(stack, size);
					printf("Sklad je bil izpraznjen.\n--------------\n\n");
					
				}else if(cmd == 5){ //izhod
					break;
					
				}else if(cmd == 1337){ //easter egg
					printf("\nDesigned and programmed by Tomaz Tomsic. All rights reserved.\n--------------\n\n");
					
				}else{ //ce je izbor neveljaven
					printf("[ERROR]: Unknown command '%d'.\n--------------\n\n", cmd);
				}
			}
		}
	}
	
	printf("----------------------------------------------------------\n"); //footer
	return 0;
}
