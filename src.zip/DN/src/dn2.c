#include <stdio.h>
#include <stdlib.h>

// Avtor: 63100279

int main(int argc, char *argv[]) {

	int arg[4]={0,0,0,0};
	if(argc < 2) {
		printf("Katero akcijo naj izvedem? ");
		scanf("%d",&arg[0]);

		if(arg[0] == 1) {
			printf("Vpisi zacetek tabele: ");
			scanf("%d",&arg[1]);
			printf("Vpisi konec tabele: ");
			scanf("%d",&arg[2]);
		}
		else if(arg[0] == 2) {
			printf("Vpisi sekunde: ");
			scanf("%d",&arg[1]);
		}
		else if(arg[0] == 3) {
			printf("Vpisi ure: ");
			scanf("%d",&arg[1]);
			printf("Vpisi minute: ");
			scanf("%d",&arg[2]);
			printf("Vpisi sekunde: ");
			scanf("%d",&arg[3]);
		}
	}
	else {
		if(argc > 1)
			arg[0]=atoi(argv[1]);
		if(argc > 2)
			arg[1]=atoi(argv[2]);
		if(argc > 3)
			arg[2]=atoi(argv[3]);
		if(argc > 4)
			arg[3]=atoi(argv[4]);
	}

	if(arg[0] == 1 || arg[0] == 2) {
		int i=arg[1];
		do {
			int ure=i/3600;
			int minute=i%3600/60;
		    int sekunde=i%3600%60;
			printf("%d sekund je %d ur, %d minut, %d sekund\n", i, ure, minute, sekunde);
			i++;
		} while(i <= arg[2]);
	}
	else if(arg[0] == 3) {
		int vSekundah=arg[1]*3600+arg[2]*60+arg[3];
		printf("%d ura, %d minut, %d sekund je %d sekund.\n", arg[1], arg[2], arg[3], vSekundah);	
	}
	else
		printf("Niste izbrali veljavne akcije!\n");

	return 0;
}
