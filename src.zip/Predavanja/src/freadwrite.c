#include <stdio.h>
#include <stdlib.h>

#define N 10000

int main(int argc, char **args) {
  FILE *fIN  = fopen("e:\\medo.bmp",  "rb");
  FILE *fOUT = fopen("e:\\medoB.bmp", "wb");

  if (fIN == NULL || fOUT == NULL) {
    fprintf(stderr, "Napaka");
    exit(1);
  }

  char buffer[N];
  int koliko;
  while((koliko = fread(buffer, 1,N, fIN))>0) {

    fwrite(buffer,1,koliko, fOUT);
  }

  fclose(fIN);
  fclose(fOUT);
}
