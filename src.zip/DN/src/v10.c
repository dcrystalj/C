// avtor: 63110464

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct celoStevilo {
	int st;
	struct celoStevilo *nasl;
} celoSt;

celoSt * novoSt(int s) {
	celoSt *novo = malloc(sizeof(celoSt));
	novo->st = s;
	novo->nasl = NULL;
	return novo;
}

celoSt * brisi(celoSt *z, int s) {
    if (z == NULL) {
		return NULL;
	}
	if (z->st == s) {
		celoSt *nZ = z->nasl;
		free(z);
		return nZ;
	}
	celoSt *temp = z;
	while (temp->nasl != NULL) {
		if ((temp->nasl)->st == s) {
			celoSt *p = temp->nasl;
			temp->nasl = (temp->nasl)->nasl;
			free(p);
		} else {
			temp = temp->nasl;
		}
	}
	return z;
}

celoSt * dodajU(celoSt *z, celoSt *c) {
	if (z == NULL) {
		return c;
	} 
	if (z->st > c->st) {
		c->nasl = z;
		return c;
	}
	else {
		celoSt *temp = z;
		while (temp->nasl != NULL) {
			if ((temp->nasl)->st < c->st) {
				temp = temp->nasl;
			} else {
				c->nasl = temp->nasl;
				break;
			}
			
        }
		temp->nasl = c;
		return z;
	}
}

void izpisiSt(celoSt* z) {
	printf("%d\n", z->st);
}

void izpisi(celoSt* z) {
	while (z != NULL) {
		izpisiSt(z);
		z = z->nasl;
	}
}

int main (int argc, char** args) {
    celoSt *z;
	z = NULL;

	z = dodajU(z, novoSt(4));
	z = dodajU(z, novoSt(7));
	z = dodajU(z, novoSt(1));
	z = dodajU(z, novoSt(9));
	z = dodajU(z, novoSt(3));
	z = dodajU(z, novoSt(2));

	z = brisi(z, 1);
	z = brisi(z, 7);

	izpisi(z);

	return 0;
}
