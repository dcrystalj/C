#include <stdio.h>

typedef struct {
  int x;
  int y;
} tocka;

void zamenjaj(tocka *t) {
//  int tmp = (*t).x;
//  (*t).x = (*t).y;
//  (*t).y = tmp;

    int tmp = t -> x;
    t -> x  = t -> y;
    t -> y  = tmp;
}

void zamenjajTabela(char a[]) {
  char tmp = a[0];
  a[0] = a[1];
  a[1] = tmp;
}


int main(int argc, char **args) {

  tocka t;

  t.x = 2;
  t.y = 5;

  printf("%d, %d\n", t.x, t.y);
  zamenjaj(&t);
  printf("%d, %d\n", t.x, t.y);

  char tab[] = {'a','b'};
  printf("%c, %c\n", tab[0], tab[1]);
  zamenjajTabela(tab);
  printf("%c, %c\n", tab[0], tab[1]);
}

