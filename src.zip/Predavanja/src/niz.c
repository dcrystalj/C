main() {
  char niz1[10] = "ABC";
  char niz2[]   = "DEF";

  printf("%d, %d \n", sizeof(niz1), 
    sizeof(niz2));

  strcpy(niz1, niz2);
  printf("%s\n", niz1);
}
