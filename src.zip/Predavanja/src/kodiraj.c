#include <string.h>

int zamik=3;

void kodiraj(char niz[]){
  int i;
  for(i=0; i<strlen(niz); i++) {
    niz[i] = 'A'+(niz[i]-'A'+zamik)%26;
  }
}
void odkodiraj(char niz[]){
  int i;
  for(i=0; i<strlen(niz); i++) {
    niz[i] = 'A'+(26+niz[i]-'A'-zamik)%26;
  }
}
